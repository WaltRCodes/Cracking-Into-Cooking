package com.walter.springbootDemo.mySpringBootApp.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.walter.springbootDemo.mySpringBootApp.exception.ResourceNotFoundException;
import com.walter.springbootDemo.mySpringBootApp.model.Recipe;
import com.walter.springbootDemo.mySpringBootApp.repository.RecipeRepository;

@RestController
@RequestMapping("/walter_api/v2")
public class RecipeController {
	
	@Autowired
	private RecipeRepository recipeRepository;
	@GetMapping("/recipes")
	public List<Recipe> getAllRecipes(){
		return recipeRepository.findAll();
	}
	
	@GetMapping("/recipes/{id}")
	public ResponseEntity<Recipe> getUserById(@PathVariable(value = "id") Long recipeId)
	 throws ResourceNotFoundException {
		Recipe recipe = recipeRepository.findById(recipeId)
				.orElseThrow(() -> new ResourceNotFoundException("Recipe not found for this id ::"
						+recipeId));
		return ResponseEntity.ok().body(recipe);
	}
	
	
	@PostMapping("/recipes")
	public Recipe createRecipe(@Valid @RequestBody Recipe recipe) {
		return recipeRepository.save(recipe);
	}
	
	@PutMapping("/recipes/{id}")
	public ResponseEntity<Recipe> updateIngredientById(@PathVariable(value = "id") Long recipeId, @Valid @RequestBody Recipe recipeDetails)
			 throws ResourceNotFoundException {
		Recipe recipe = recipeRepository.findById(recipeId)
						.orElseThrow(() -> new ResourceNotFoundException("Recipe not found for this id ::"
								+recipeId));
				//return ResponseEntity.ok().body(employee);
		recipe.setDescription(recipeDetails.getDescription());
		recipe.setImage(recipeDetails.getImage());
		recipe.setName(recipeDetails.getName());
		recipe.setUserId(recipeDetails.getUserId());
		recipe.setIngredients(recipeDetails.getIngredients());
				
				final Recipe updatedRecipe = recipeRepository.save(recipe);
				return ResponseEntity.ok(updatedRecipe);
			}
	
	
	
	@DeleteMapping("/recipes/{id}")
	public Map<String, Boolean> deletedRecipe(@PathVariable(value = "id") Long recipeId)
			 throws ResourceNotFoundException {
		Recipe recipe = recipeRepository.findById(recipeId)
						.orElseThrow(() -> new ResourceNotFoundException("Recipe not found for this id ::"
								+recipeId));
		recipeRepository.delete(recipe);
				Map<String, Boolean> response = new HashMap<>();
				response.put("deleted users", Boolean.TRUE);
				
				return response;
		
	}
}

