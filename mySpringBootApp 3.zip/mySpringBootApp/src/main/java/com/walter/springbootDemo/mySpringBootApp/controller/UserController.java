package com.walter.springbootDemo.mySpringBootApp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.walter.springbootDemo.mySpringBootApp.exception.ResourceNotFoundException;
import com.walter.springbootDemo.mySpringBootApp.model.User;
import com.walter.springbootDemo.mySpringBootApp.repository.UserRepository;

@RestController
@RequestMapping("/walter_api/v2")
public class UserController {
	
	@Autowired
	private UserRepository userRepository;
	//get all employees
	@GetMapping("/users")
	public List<User> getAllUsers(){
		return userRepository.findAll();
	}
	// get all employees by id
	@GetMapping("/users/{id}")
	public ResponseEntity<User> getUserById(@PathVariable(value = "id") Long userId)
	 throws ResourceNotFoundException {
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found for this id ::"
						+userId));
		return ResponseEntity.ok().body(user);
	}
	
	// save employee
	@PostMapping("/users")
	public User createUser(@Valid @RequestBody User user) {
		return userRepository.save(user);
	}
	//Update Employee
	@PutMapping("/users/{id}")
	public ResponseEntity<User> updateUserById(@PathVariable(value = "id") Long userId, @Valid @RequestBody User userDetails)
			 throws ResourceNotFoundException {
				User user = userRepository.findById(userId)
						.orElseThrow(() -> new ResourceNotFoundException("User not found for this id ::"
								+userId));
				//return ResponseEntity.ok().body(employee);
				user.setPassword(userDetails.getPassword());
				user.setUserName(userDetails.getUserName());
				
				final User updatedUser = userRepository.save(user);
				return ResponseEntity.ok(updatedUser);
			}
	
	//Delete Employee
	
	@DeleteMapping("/users/{id}")
	public Map<String, Boolean> deletedUser(@PathVariable(value = "id") Long userId)
			 throws ResourceNotFoundException {
				User user = userRepository.findById(userId)
						.orElseThrow(() -> new ResourceNotFoundException("User not found for this id ::"
								+userId));
				userRepository.delete(user);
				Map<String, Boolean> response = new HashMap<>();
				response.put("deleted users", Boolean.TRUE);
				
				return response;
		
	}
}
